#!/bin/bash
echo -n "$1" | openssl enc -base64
echo -n "$2" | openssl enc -base64
