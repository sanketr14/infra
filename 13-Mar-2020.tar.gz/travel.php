<?php
include_once('include/header.php');
?>
<!-- Page Content -->
 <div class="container">
    <div class="row mt-5 travel-section">
     <div class="col-md-12"><h1>Travel</h1></div>   
     <div class="col-lg-4">
        <a href="/epiconin/videoplayer.php">
     	<figure><img src="images/Travel/ekaant-1280x720-289x163.jpg" alt="" class="img-fluid" ></figure>
        <h2>Ekaant</h2>
        <p>India is known for its remarkable architecture and serene landscapes. Its rich history is steeped in mystery; its vastness - lends itself to several stories and urban legends. Ekaant takes you through the abandoned roads and alleys of some of India's historic locations. Travelling through the spread out palaces and deserted forts, the show documents and investigates the eerie processes of abandonment of each site.</p>
        </a>
     </div>
     <div class="col-lg-4">
     	<figure><img src="images/Travel/indepedia-showposter-1-289x163.jpg" alt="" class="img-fluid"></figure>
        <h2>Indipedia</h2>
        <p>Indipedia is an anchor driven episodic series that will showcases the CUSTOMS OF INDIA' that are so obvious but not so researched. The word CUSTOM' in this case refers to an umbrella term for rituals, superstitions, symbols, inventions, livelihoods, arts, crafts, culture and more. Indipedia would unearth simple and logical meanings behind everyday practices across India through the eyes of a young firangi.</p>
     </div>
     <div class="col-lg-4">
     	<figure><img src="images/Travel/jourenysinindia1280x720-289x163.jpg" alt="" class="img-fluid"></figure>
        <h2>Journeys in India</h2>
        <p>Whether you refer to Udaipur as the City of Lakes or the City of Dawn, you're sure to agree that romance and beauty fill the air. In Jaipur, we tour the Pink City, paying close attention to such architectural treasures as the Palace of Winds (Hawa Mahal) and the Amber Fort.</p>
     </div>
    </div>

    <div class="row mt-3 travel-section">
     <div class="col-lg-4">
     	<figure><img src="images/Travel/roadless-travel-rlt-showposter-289x163.jpg" alt="" class="img-fluid" ></figure>
        <h2>Road Less Travelled</h2>
        <p>Jonathan Legg, the globe-trotter, is back! To Jonathan, travelling is quintessentially a quest for unusual, exotic adventures, and often the bizarre side of a destination. Join him as he travels through India in search of exotic and unique experiences; moments not found in the mainstream and rutted path of millions, but on the Road Less Travelled.</p>
     </div>
     <div class="col-lg-4">
     	<figure><img src="images/Travel/sanrachana-show-poster-289x163.jpg" alt="" class="img-fluid" ></figure>
        <h2>Sanrachna</h2>
        <p>Shelter - one of mankind's most basic physiological needs. At least that's what it started out as at the beginning of time. From dwelling in caves to carving out temples in mountains, mankind has redefined shelter with every passing era. Though the underlying philosophy of any monument is to serve some sort of function, great architecture is fuelled by imagination. India's architecture is built on that very imagination and is a fascinating fusion of both art and science.</p>
     </div>
     <div class="col-lg-4">
     	<figure><img src="images/Travel/Wilderness-Days-ShowPoster-289x163.jpg" alt="" class="img-fluid" ></figure>
        <h2>Wilderness Days</h2>
        <p>India is a land of lush tropical forests and a wide range of wildlife, right from large predators to small endemic creatures. Home of the majestic Bengal tigers, lithe leopards, and many other such amazing creatures, India offers a wildlife experience that is exhilarating, exciting, and full of surprises. Wilderness Days is a show where Tom Alter takes you across the length and breadth of the country, traversing some of the wildest forests to show you footage of unbelievably close encounters of animals with other animals and with humans in their natural habitats</p>
     </div>
    </div>

 </div>
<?php
include_once('include/footer.php');
?>