<?php
include_once('include/header.php');
?>
<!-- Page Content -->
<div class="container">
  <div class="row mt-5">
 	  <div class="col-md-8">
      <div id="myElement"></div>
    </div>
    <div class="col-md-4 text-center">

      <h2>Ekaant</h2><br>
      <p class="main-txt">
		    India is known for its remarkable architecture and serene landscapes. Its rich history is steeped in mystery; its vastness - lends itself to several stories and urban legends. Ekaant takes you through the abandoned roads and alleys of some of India's historic locations. Travelling through the spread out palaces and deserted forts, the show documents and investigates the eerie processes of abandonment of each site.
      </p>

    </div>
  </div>
</div>
    <script type="text/JavaScript">

      jwplayer("myElement").setup({ 
        playlist: [{
                //file: "https://epicon-vh.akamaihd.net/i/content/videos/2017/8/5997185076696118272b0000_138473_main.smil/master.m3u8?hdnea=st=1583906245~exp=1584511045~acl=/*~hmac=079a9c48abe88603f8cc304a675f00160f5d412cc05f1dae2a7ce61bc2176392"
                file: "https://epicon-vh.akamaihd.net/i/content/videos/2017/8/5950b6871d41c86c790001d5_playlist.smil/master.m3u8?hdnea=st=1583940270~exp=1584545070~acl=/*~hmac=d531edd045eb86c5677bb4904abc5d8f9702be40b78d037a1ccb48576abcf63c"
            }],
        advertising: {
          client: "googima",
           adscheduleid: "DS18JtL3",
          schedule: [
            {
              offset: "pre",
              tag: "https://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/124319096/external/single_ad_samples&ciu_szs=300x250&impl=s&gdfp_req=1&env=vp&output=vast&unviewed_position_start=1&cust_params=deployment%3Ddevsite%26sample_ct%3Dlinear&correlator="
            }
          ],
          rules: {
            startOnSeek: "pre",
            timeBetweenAds: 300
          }
        }    
      });

    </script> 
<?php
include_once('include/footer.php');
?>

<style>

  @media screen and (min-width: 320px) and (max-width: 768px) {
    .jwplayer{
      width:100% !important;
    }
  }
  
</style>