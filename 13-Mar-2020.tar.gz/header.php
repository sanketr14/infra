<!DOCTYPE html>
<html lang="en">

<head>

 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <meta name="description" content="">
 <meta name="author" content="">

 <title>Epic ON App</title>

 <!-- Bootstrap core CSS -->
 <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <script src="js/jwplayer.js?v=1583751374"></script>
 <script>jwplayer.key="KjZLp2bXKLFcL2hCVYkFGYOMt5R/lLYPPlMUHJNj5VI3fqJ2";</script>

 <style>
 	.background-img{
		background-image: url(images/desktop-background.jpg);
		width: 100%;
		background-size: 100%;
		height: 100vh;
	}

	img.right-img {
	    width: 60%;
	    margin: 0 auto;
	}

	.col-lg-12.text-center {
	    margin-top: 5%;
	}

	p.main-txt {
	    color: #ffffff;
	    text-align: justify;
	}

	.navbar-dark .navbar-nav .active>.nav-link, .navbar-dark .navbar-nav .nav-link.active, .navbar-dark .navbar-nav .nav-link.show, .navbar-dark .navbar-nav .show>.nav-link {
	    color: #ffcd67;
        font-size: 20px;
	}

	.navbar-dark .navbar-nav .nav-link {
	    color: #fff;
        font-size: 20px;
	}

	.navbar-dark .navbar-nav .nav-link:focus, .navbar-dark .navbar-nav .nav-link:hover {
	    color: #ffcd67;
        font-size: 20px;
	}

	.bg-dark {
	    background-color: #343a40!important;
	    background: linear-gradient(180deg,#000 0,rgba(0,0,0,.7) 50%,transparent 100%);
	}

	p.visit-txt {
	    border: 1.5px solid #ffcd67;
	    color: #ffcd67;
	    width: 100%;
	    text-align: center;
	    border-radius: 50px;
	    font-size: 22px;
	    padding: 9px;
	    margin: 0 auto;
	}

	.visit {
	    width:100%;
        margin-top: 20px;
	}

	p.visit-txt {
	    border: 1.5px solid #ffcd67;
	    color: #ffcd67;
	    width: 100%;
	    text-align: center;
	    border-radius: 50px;
	    font-size: 22px;
	    padding: 4px 30px;
	    margin: 0 auto;
	    outline: none;
	    text-decoration: none;
	}

	p.visit-txt:hover {
	    border: 1.5px solid #000000;
	    color: #000000;
	    width: 100%;
	    text-align: center;
	    border-radius: 50px;
	    font-size: 22px;
	    padding: 4px 30px;
	    margin: 0 auto;
	    outline: none;
	    background: #ffcd67;
	    ext-decoration: none;
	}
	a.button-all {
	    margin: 0 20px;
	}

	a,fieldset,img{
		text-decoration: none;
	}

	.navbar-dark .navbar-toggler {
	    color: rgba(255,255,255,.5);
	    border-color: rgba(255,255,255,.1);
	    display: none;
	}

	a:hover {
	    color: transparent;
	    text-decoration: underline;
	}
	
	@media screen and (min-width:320px) and (max-width:767px){
		.visit{
			display: block;
		}
	}
.food-section h1{font-size:30px;color:#fff;margin-bottom: 25px;}	
.food-section h2{color:#fff;font-size:24px;}
.food-section p{color:#fff;font-size:14px;}
.food-section img{min-width:100%;}
.travel-section h1{font-size:30px;color:#fff;margin-bottom: 25px;}
.travel-section img{min-width:100%;}
.travel-section h2{color:#fff;font-size:24px;}
.travel-section p{color:#fff;font-size:14px;}
.history-section img{min-width:100%;}
.history-section h1{font-size:30px;color:#fff;margin-bottom: 25px;}
.history-section h2{color:#fff;font-size:24px;}
.history-section p{color:#fff;font-size:14px;}
.footer-copyright p{margin-bottom: 0px}

ul#tabs {
    display: flex;
    flex-direction: row;
    list-style: none;
    justify-content: center;
    padding-left: 0px;
}
ul#tabs li {
    margin: 0px 15px;
}
ul#tabs li a{text-decoration: none;}
.contain {
    width: 100%;
    height: auto;
    float: left;
    clear: both;
}

.footer-copyright.text-center.py-3{
	background-color: #343a40!important;
    background: linear-gradient(180deg,#000 0,rgba(0,0,0,.7) 50%,transparent 100%);
    width: 100%;
}

.text-center {
    text-align: center!important;
    color: #fff;
}
.footer-copyright ul.nav {
    width: 100%;
    height: auto;
    display: flex;
    justify-content: center;
    margin-bottom: 15px;
}
.footer-copyright ul.nav li {
    padding: 0px 13px;
    text-align: center;
}
.footer-copyright ul.nav li a{color:#fff;text-decoration: none}
@media screen and (min-width:320px) and (max-width:767px){
	.navbar-dark .navbar-toggler{display:block}
	ul#tabs {
	    display: flex;
	    flex-direction: column;
	    list-style: none;
	    justify-content: center;
	    padding-inline-start: 0px;
	}

	ul#tabs li a {
	    text-decoration: none;
	    display: block;
	    margin-bottom: 15px;
	}
}
.about-us h2{font-size:28px;color:#fff;}
.about-us p{color:#fff}
.privacy-policy li{color:#fff;}
.privacy-policy h1{font-size:28px;color:#fff;}
.privacy-policy h2,.privacy-policy h3{font-size:22px;color:#fff;}
.privacy-policy p{font-size:15px;color:#fff;}
.contact-us h2{font-size:22px;color:#fff;text-align:center;}
.contact-us p{font-size:15px;color:#fff;text-align:center}
.contact-us{min-height:67vh; justify-content: center; align-items: center;}
.contact-us a{font-size:15px;color:#fff;line-height:18px;}
 </style>
</head>
<body class="background-img">
 <!-- Navigation -->
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
   <div class="container">
     <a class="navbar-brand" href="index.php"><img src="images/epic-logo.png" class="right-img"></a>
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
       <ul class="navbar-nav ml-auto">
	   	<li class="nav-item">
           <a class="nav-link" href="aboutus.php">About Us</a>
         </li>
         <li class="nav-item ">
           <a class="nav-link" href="food.php">Food
             <span class="sr-only">(current)</span>
           </a>
         </li>
         <li class="nav-item">
           <a class="nav-link" href="travel.php">Travel</a>
         </li>
         <li class="nav-item">
           <a class="nav-link" href="history.php">History</a>
         </li>

		 <li class="nav-item">
           <a class="nav-link" href="contactus.php">Contact Us</a>
         </li>
       </ul>
     </div> 
   </div>
 </nav>